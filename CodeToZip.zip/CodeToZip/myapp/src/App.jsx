// src/App.jsx
import React from "react";
import { Routes, Route } from "react-router-dom";
import Layout from "./Layout.jsx";
import Home from "./Pages/Home.jsx";
import Game1 from "./Pages/Game1.jsx";
import Game2 from "./Pages/Game2.jsx";
import Game3 from "./Pages/Game3.jsx";
import Game4 from "./Pages/Game4.jsx";
import Game5 from "./Pages/Game5.jsx";
import Game6 from "./Pages/Game6.jsx";
import Game7 from "./Pages/Game7.jsx";
import Game8 from "./Pages/Game8.jsx";
import Game9 from "./Pages/Game9.jsx";
import Game10 from "./Pages/Game10.jsx";
import Game11 from "./Pages/Game11.jsx";
import Game12 from "./Pages/Game12.jsx";
import Game13 from "./Pages/Game13.jsx";
import Game14 from "./Pages/Game14.jsx";
import Game15 from "./Pages/Game15.jsx";
import Game16 from "./Pages/Game16.jsx";
import Game17 from "./Pages/Game17.jsx";
import Game18 from "./Pages/Game18.jsx";
import Game19 from "./Pages/Game19.jsx";
import Game20 from "./Pages/Game20.jsx";
import Game21 from "./Pages/Game21.jsx";
import Game22 from "./Pages/Game22.jsx";
import Game23 from "./Pages/Game23.jsx";
import Game24 from "./Pages/Game24.jsx";
import Login from "./Pages/Login.jsx";


export default function App() {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/Home" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/game1" element={<Game1 />} />
          <Route path="/game2" element={<Game2 />} />
          <Route path="/game3" element={<Game3 />} />
          <Route path="/game4" element={<Game4 />} />
          <Route path="/game5" element={<Game5 />} />
          <Route path="/game6" element={<Game6 />} />
          <Route path="/game7" element={<Game7 />} />
          <Route path="/game8" element={<Game8 />} />
          <Route path="/game9" element={<Game9 />} />
          <Route path="/game10" element={<Game10 />} />
          <Route path="/game11" element={<Game11 />} />
          <Route path="/game12" element={<Game12 />} />
          <Route path="/game13" element={<Game13 />} />
          <Route path="/game14" element={<Game14 />} />
          <Route path="/game15" element={<Game15 />} />
          <Route path="/game16" element={<Game16 />} />
          <Route path="/game17" element={<Game17 />} />
          <Route path="/game18" element={<Game18 />} />
          <Route path="/game19" element={<Game19 />} />
          <Route path="/game20" element={<Game20 />} />
          <Route path="/game21" element={<Game21 />} />
          <Route path="/game22" element={<Game22 />} />
          <Route path="/game23" element={<Game23 />} />
          <Route path="/game24" element={<Game24 />} />
      </Routes>
    </Layout>
  );
}
