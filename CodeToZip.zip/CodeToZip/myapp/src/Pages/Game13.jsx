
import React, { useState, useEffect, useCallback } from "react";
import { UserService as User } from "@/services/user";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { ArrowLeft, ArrowRight, Trophy, CheckCircle, Target, ThumbsDown, Eye } from "lucide-react";
import { Button } from "@/components/ui/button";
import PlayingCard from "../components/shared/PlayingCard";
import { Progress } from "@/components/ui/progress";
import { motion, AnimatePresence } from 'framer-motion';

const explanationSlides = [
    {
        title: "The 'Fit or Fold' Principle",
        content: "Post-flop poker is about assessing how well your pre-flop hand 'fits' with the community cards. The 'Fit or Fold' principle is a disciplined approach: if the flop doesn't significantly improve your hand or give you a strong draw, you should often be prepared to fold. Chasing weak hands or draws is one of the fastest ways to lose chips. This principle forces you to make a realistic assessment of your situation.",
        icon: Eye
    },
    {
        title: "What is a Good 'Fit'?",
        content: "A good fit means the flop has given you a strong made hand or a powerful draw. Examples include: Made Hands: Top pair with a good kicker (e.g., holding A-K on a K-7-2 flop), two pair, a set (three-of-a-kind), a straight, or a flush. Strong Draws: An open-ended straight draw (8 outs), a flush draw (9 outs), or a combination of both (combo draw, 12+ outs). These hands have clear potential and are worth investing more money in.",
        icon: Target
    },
    {
        title: "Recognizing a 'Fold' Situation",
        content: "A 'fold' situation occurs when the flop completely misses your hand. For example, you hold A-K and the flop comes J-7-2. You have nothing but two overcards. While you might sometimes win by bluffing or hitting an Ace or King on a later street, continuing without a plan is dangerous. Unless you have a specific reason to believe you can outplay your opponent, folding is often the most disciplined and profitable long-term play.",
        icon: ThumbsDown
    }
];

const finalChallengeQuestions = [
    {
        hand: ["A♠", "K♦"],
        board: ["K♥", "8♣", "3♠"],
        question: "Does this hand 'fit' the flop?",
        options: ["Yes, strong fit", "No, it's a fold"],
        correct: 0,
        feedback: "Yes. You've hit top pair with the best possible kicker. This is a very strong fit and a hand you should be looking to get value with."
    },
    {
        hand: ["7♣", "8♣"],
        board: ["5♦", "6♥", "A♠"],
        question: "Does this hand 'fit' the flop?",
        options: ["Yes, strong draw", "No, weak hand"],
        correct: 0,
        feedback: "Yes. You've flopped an open-ended straight draw (8 outs). This is a strong draw and a good fit to continue with."
    },
    {
        hand: ["A♠", "Q♦"],
        board: ["J♥", "8♣", "3♠"],
        question: "Does this hand 'fit' the flop?",
        options: ["Yes, I have overcards", "No, it's a fold"],
        correct: 1,
        feedback: "No. While you have two overcards, this is a very weak hand with no made value and no strong draw. According to the 'Fit or Fold' principle, this is a clear fold."
    },
    {
        hand: ["10♥", "10♦"],
        board: ["A♣", "K♦", "Q♠"],
        question: "You have pocket tens. Does your hand 'fit' this flop?",
        options: ["Yes, it's a pair", "No, too many overcards"],
        correct: 1,
        feedback: "No. Your pocket pair is now an underpair to three higher cards on the board. This is a dangerous situation and a very poor fit. It's a fold against any aggression."
    },
    {
        hand: ["A♥", "5♥"],
        board: ["K♥", "9♥", "2♠"],
        question: "Does this hand 'fit' the flop?",
        options: ["Yes, nut flush draw", "No, just ace-high"],
        correct: 0,
        feedback: "Yes. You've flopped the nut flush draw. This is a powerful draw and an excellent fit with the flop."
    },
    {
        hand: ["K♠", "J♠"],
        board: ["A♦", "Q♣", "10♥"],
        question: "Does this hand 'fit' the flop?",
        options: ["Yes, nut straight", "No, no pair"],
        correct: 0,
        feedback: "Yes! You've flopped the best possible hand, the nut straight. This is the ultimate 'fit'."
    }
];

export default function Game13() {
  const [currentStage, setCurrentStage] = useState('intro');
  const [currentSlide, setCurrentSlide] = useState(0);
  const [slideDirection, setSlideDirection] = useState(1);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState(null);
  const [showExplanation, setShowExplanation] = useState(false);
  const [finalScore, setFinalScore] = useState(0);
  const [user, setUser] = useState(null);
  const navigate = useNavigate();

    useEffect(() => {
        const loadUser = async () => {
            try {
                const currentUser = await User.me();
                setUser(currentUser);
            } catch (error) {
                console.error("User not loaded.", error);
            }
        };
        loadUser();
    }, []);

    const completeGame = async (passed) => {
        if (!user) return;

        if (passed) {
            const today = new Date().toISOString().split('T')[0];
            await User.completeGame(1);
        }
        navigate(createPageUrl("Home"));
    };

    const handleAnswer = () => {
        const question = finalChallengeQuestions[currentQuestion];
        if (showExplanation) {
            // Move to next question
            if (currentQuestion < finalChallengeQuestions.length - 1) {
                setCurrentQuestion(q => q + 1);
                setShowExplanation(false);
                setSelectedAnswer(null);
            } else {
                setCurrentStage('completion');
            }
        } else {
            // Check answer
            if (selectedAnswer === question.correct) {
                setFinalScore(s => s + 1);
            }
            setShowExplanation(true);
        }
    };

    const handleSlideChange = (newSlide) => {
        setSlideDirection(newSlide > currentSlide ? 1 : -1);
        setCurrentSlide(newSlide);
    };

    const renderIntro = () => (
        <div className="max-w-4xl mx-auto text-center">
            <div className="bg-black/20 backdrop-blur-md rounded-2xl p-8 border border-green-600/30">
                <Target className="w-16 h-16 text-yellow-400 mx-auto mb-6" />
                <h1 className="text-4xl font-bold text-white mb-4">Game 13: Flop Defines the Hand</h1>
                <h2 className="text-2xl font-semibold text-green-300 mb-6">Mastering the "Fit or Fold" Principle</h2>
                <p className="text-green-200 text-lg mb-8">
                    Learn to quickly assess if the flop strengthens your hand enough to continue playing or if it's time to save your chips and fold.
                </p>
                <Button onClick={() => setCurrentStage('explanation')} className="bg-yellow-500 hover:bg-yellow-600 text-black font-bold px-8 py-3 text-lg">Start Learning <ArrowRight className="ml-2 w-5 h-5" /></Button>
            </div>
        </div>
    );

    const renderExplanation = () => {
        const slide = explanationSlides[currentSlide];
        const Icon = slide.icon;

        return (
            <div className="max-w-5xl mx-auto">
                <AnimatePresence mode="wait">
                    <motion.div
                        key={currentSlide}
                        initial={{ opacity: 0, x: slideDirection * 300 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -slideDirection * 300 }}
                        transition={{ duration: 0.5, ease: "easeInOut" }}
                    >
                        <div className="bg-black/20 backdrop-blur-md rounded-2xl p-8 border border-green-600/30">
                            <div className="text-center mb-6">
                                <Icon className="w-12 h-12 text-yellow-400 mx-auto mb-4" />
                                <h2 className="text-3xl font-bold text-white mb-2">{slide.title}</h2>
                            </div>
                            <div className="bg-white/10 rounded-xl p-6 min-h-[150px] flex items-center">
                                <p className="text-green-200 text-lg leading-relaxed">{slide.content}</p>
                            </div>
                        </div>
                    </motion.div>
                </AnimatePresence>
                <div className="flex justify-between items-center mt-6">
                    <Button onClick={() => handleSlideChange(Math.max(0, currentSlide - 1))} disabled={currentSlide === 0} variant="outline" className="border-green-600 text-green-300 hover:bg-green-600/20"><ArrowLeft className="mr-2 w-4 h-4" /> Previous</Button>
                    <div className="flex gap-2">
                        {explanationSlides.map((_, index) => (
                            <button key={index} onClick={() => handleSlideChange(index)} className={`w-3 h-3 rounded-full ${currentSlide === index ? 'bg-yellow-400' : 'bg-green-700'}`}></button>
                        ))}
                    </div>
                    {currentSlide < explanationSlides.length - 1 ? (
                        <Button onClick={() => handleSlideChange(currentSlide + 1)} className="bg-green-600 hover:bg-green-700 text-white">Next <ArrowRight className="ml-2 w-4 h-4" /></Button>
                    ) : (
                        <Button onClick={() => { setCurrentStage('challenge'); setCurrentQuestion(0); }} className="bg-yellow-500 hover:bg-yellow-600 text-black font-bold">Start Challenge <ArrowRight className="ml-2 w-4 h-4" /></Button>
                    )}
                </div>
            </div>
        );
    };

    const renderChallenge = () => {
        const question = finalChallengeQuestions[currentQuestion];
        const isCorrect = selectedAnswer === question.correct;

        return (
            <div className="max-w-4xl mx-auto">
                <div className="bg-black/20 backdrop-blur-md rounded-2xl p-8 border border-red-600/30">
                    <h2 className="text-3xl font-bold text-white text-center mb-2">Fit or Fold Challenge</h2>
                    <p className="text-center text-red-300 mb-6">Question {currentQuestion + 1} of {finalChallengeQuestions.length}</p>
                    <Progress value={((currentQuestion + 1) / finalChallengeQuestions.length) * 100} className="mb-6" />


                    <div className="bg-white/5 rounded-xl p-6 mb-6">
                        <div className="flex justify-center items-center gap-4 mb-4">
                            <p className="text-white font-bold">Board:</p>
                            <div className="flex gap-2">
                                {question.board.map(card => <PlayingCard key={card} card={card} />)}
                            </div>
                        </div>
                        <div className="flex justify-center items-center gap-4">
                            <p className="text-white font-bold">Your Hand:</p>
                            <div className="flex gap-2">
                                {question.hand.map(card => <PlayingCard key={card} card={card} />)}
                            </div>
                        </div>
                        <h4 className="text-xl font-bold text-white text-center mt-6">{question.question}</h4>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
                        {question.options.map((option, index) => (
                            <Button
                                key={index}
                                variant={selectedAnswer === index ? (isCorrect ? "default" : "destructive") : "secondary"}
                                className="h-16 text-lg bg-white/10 hover:bg-white/20"
                                onClick={() => !showExplanation && setSelectedAnswer(index)}
                                disabled={showExplanation}
                            >
                                {option}
                            </Button>
                        ))}
                    </div>

                    {showExplanation && (
                        <div className={`rounded-xl p-6 mb-6 ${isCorrect ? 'bg-green-900/30 border-green-500' : 'bg-red-900/30 border-red-500'} border`}>
                            <div className="flex items-center gap-2 mb-3">
                                {isCorrect ? <CheckCircle className="w-6 h-6 text-green-400" /> : <ThumbsDown className="w-6 h-6 text-red-400" />}
                                <h3 className="text-xl font-bold text-white">{isCorrect ? 'Correct!' : 'Incorrect'}</h3>
                            </div>
                            <p className="text-green-200">{question.feedback}</p>
                        </div>
                    )}

                    <div className="text-center mt-4">
                        <Button
                            onClick={handleAnswer}
                            disabled={selectedAnswer === null && !showExplanation}
                            className={`px-8 py-3 text-lg ${showExplanation ? "bg-yellow-500 hover:bg-yellow-600 text-black" : "bg-yellow-500 hover:bg-yellow-600 text-black"}`}
                        >
                            {showExplanation ? 'Next' : 'Submit'}
                        </Button>
                    </div>
                </div>
            </div>
        );
    };

    const renderCompletion = () => {
        const passed = finalScore >= 5;

        const retryChallenge = () => {
            setCurrentStage('challenge');
            setCurrentQuestion(0);
            setSelectedAnswer(null);
            setShowExplanation(false);
            setFinalScore(0);
        };

        return (
            <div className="max-w-4xl mx-auto text-center">
                <div className={`bg-black/20 backdrop-blur-md rounded-2xl p-8 border ${passed ? 'border-green-600/30' : 'border-red-600/30'}`}>
                    <Trophy className="w-20 h-20 text-yellow-400 mx-auto mb-6" />
                    <h2 className="text-4xl font-bold text-white mb-4">{passed ? "Congratulations!" : "Challenge Complete"}</h2>

                    <div className="bg-white/10 rounded-xl p-6 mb-8">
                        <h3 className="text-2xl font-bold text-white mb-2">Your Score: {finalScore} / {finalChallengeQuestions.length}</h3>
                        <p className={`font-bold text-lg ${passed ? 'text-green-400' : 'text-red-400'}`}>
                            {passed ? "Excellent! You've passed the challenge." : "You need at least 5 correct answers to pass. Keep practicing!"}
                        </p>
                    </div>

                    {passed ? (
                        <>
                            <p className="text-green-200 text-lg mb-8">
                                Congratulations! You can now instantly recognize whether to continue with a hand post-flop or save your chips for a better opportunity.
                            </p>
                            <Button onClick={() => completeGame(true)} className="bg-yellow-500 hover:bg-yellow-600 text-black font-bold px-8 py-3 text-lg">
                                Complete & Return to Home <ArrowRight className="ml-2 w-5 h-5" />
                            </Button>
                        </>
                    ) : (
                        <>
                             <p className="text-red-200 text-lg mb-8">
                                Mastering the 'Fit or Fold' principle is key. Review the concepts and try the challenge again.
                            </p>
                            <div className="flex justify-center gap-4">
                                <Button onClick={retryChallenge} className="bg-yellow-400 hover:bg-yellow-500 text-black font-bold px-8 py-3 text-lg">
                                    Try Again
                                </Button>
                                <Button onClick={() => completeGame(false)} className="bg-yellow-400 hover:bg-yellow-500 text-black font-bold px-8 py-3 text-lg">
                                    Return to Home
                                </Button>
                            </div>
                        </>
                    )}
                </div>
            </div>
        );
    };

    const renderContent = () => {
        switch (currentStage) {
            case 'intro': return renderIntro();
            case 'explanation': return renderExplanation();
            case 'challenge': return renderChallenge();
            case 'completion': return renderCompletion();
            default: return renderIntro();
        }
    };

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="max-w-6xl mx-auto mb-6">
        <Button onClick={() => navigate(createPageUrl("Home"))} variant="outline" className="border-green-600 text-green-300 hover:bg-green-600/20">
          <ArrowLeft className="mr-2 w-4 h-4" /> Back to Home
        </Button>
      </div>
      <AnimatePresence mode="wait">
        <motion.div
            key={currentStage}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.5 }}
        >
            {renderContent()}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
